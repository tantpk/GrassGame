package com.inkblade.wuxia;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import com.android.billingclient.api.*;
import java.util.Collections;

/**
 * 墨刃江湖：風雲行 - Google Play Billing v7 原生 Java 與 JS 橋接器
 */
public class GooglePlayBillingWrapper implements PurchasesUpdatedListener {
    private final Activity activity;
    private final WebView webView;
    private BillingClient billingClient;

    public GooglePlayBillingWrapper(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        initBilling();
    }

    private void initBilling() {
        billingClient = BillingClient.newBuilder(activity)
                .setListener(this)
                .enablePendingPurchases()
                .build();

        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    // Billing Client 連接成功
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // 斷線重試邏輯
            }
        });
    }

    @JavascriptInterface
    public void launchBillingFlow(String productId) {
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(productId)
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()
                )).build();

        billingClient.queryProductDetailsAsync(params, (billingResult, list) -> {
            if (!list.isEmpty()) {
                BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(Collections.singletonList(
                                BillingFlowParams.ProductDetailsParams.newBuilder()
                                        .setProductDetails(list.get(0))
                                        .build()
                        )).build();
                billingClient.launchBillingFlow(activity, flowParams);
            }
        });
    }

    @Override
    public void onPurchasesUpdated(@NonNull BillingResult billingResult, java.util.List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                handlePurchase(purchase);
            }
        }
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            AcknowledgePurchaseParams acknowledgeParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.getPurchaseToken())
                    .build();
            billingClient.acknowledgePurchase(acknowledgeParams, res -> {
                activity.runOnUiThread(() -> {
                    // 回調通知 WebView JavaScript 發放物品
                    webView.evaluateJavascript("window.onGooglePlayPurchaseSuccess('" + purchase.getProducts().get(0) + "');", null);
                });
            });
        }
    }
}